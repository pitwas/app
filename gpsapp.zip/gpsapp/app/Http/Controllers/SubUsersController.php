<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use App\Http\Requests;

class SubUsersController extends Controller
{
    public function index(){
      return view('home');
   }  
   
  
   public function user_list(){
   
   
   $users = DB::table('sub_users')->select('name', 'email','mobile','address','address2','city','contact_person','remarks')->get();
	   return view('sub_user_list')->with('users', $users);
   }
   public function insertuser(Request $request){
      $name = $request->input('name'); 
	  $mobile = $request->input('mobile'); 
	  $email = $request->input('email'); 
	  $address = $request->input('address');    
	  $address2 = $request->input('address2');  
	  $city = $request->input('city');   
	  $contact_person = $request->input('contact_person');  
	  $remarks = $request->input('remarks');
	  
	  DB::table('sub_users')->insert(
    ['name' => $name, 'mobile' => $mobile,'email' => $email, 'address' => $address,'address2' => $address2,'city' => $city,'contact_person' => $contact_person, 'remarks' => $remarks]
);
	  
      //DB::insert('insert into sub_users (id,name,mobile,email,address,address2,city,contact_person,remarks) values(?,?,?,?,?,?,?,?,?)',[],[$mobile],[$email],[$address],[$address2],[$city],[$contact_person],[$]);
      echo "<div class='alert alert-success'>User Successfully Created !!!</div>";
      echo '<a href = "/insert">Click Here</a> to go back.';
   }
}
