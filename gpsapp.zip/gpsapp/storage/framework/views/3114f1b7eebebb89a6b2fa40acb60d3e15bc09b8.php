<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-info">
                <div class="panel-heading">All Users</div>
                <div class="panel-body">
                    <form class="form-horizontal" role="form" method="POST" action="<?php echo e(url('/user_list')); ?>">
                        <?php echo e(csrf_field()); ?>

<table class='table table-stripped'>
<tr>
  <td>Name</td>
                    <td>Email</td>
                    <td>Mobile</td>
                    <td>Address</td>
					<td>Address 2</td>
                    <td>City</td>
                    <td>Contact Person</td><td>Remarks</td>
</tr>
                      <?php foreach($users as $row): ?>
                <tr>
                    <td><?php echo e($row->name); ?></td>
                    <td><?php echo e($row->email); ?></td>
                    <td><?php echo e($row->mobile); ?></td>
                    <td><?php echo e($row->address); ?></td>
					<td><?php echo e($row->address2); ?></td>
                    <td><?php echo e($row->city); ?></td>
                    <td><?php echo e($row->contact_person); ?></td>
                    <td><?php echo e($row->remarks); ?></td>
                    <td>
                        <button type="button" class="btn btn-primary">View</button>
                        <button type="button" class="btn btn-success" value=""><a href="home?<?php echo e($row->mobile); ?>">Edit</a></button>
                        <button type="button" class="btn btn-danger">Delete</button>
                    </td>
                </tr>
			
            <?php endforeach; ?>
                    	</table>    
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>