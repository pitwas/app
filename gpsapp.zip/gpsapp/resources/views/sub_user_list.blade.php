@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-info">
                <div class="panel-heading">All Users</div>
                <div class="panel-body">
                    <form class="form-horizontal" role="form" method="POST" action="{{ url('/user_list') }}">
                        {{ csrf_field() }}
<table class='table table-stripped'>
<tr>
  <td>Name</td>
                    <td>Email</td>
                    <td>Mobile</td>
                    <td>Address</td>
					<td>Address 2</td>
                    <td>City</td>
                    <td>Contact Person</td><td>Remarks</td>
</tr>
                      @foreach($users as $row)
                <tr>
                    <td>{{$row->name}}</td>
                    <td>{{$row->email}}</td>
                    <td>{{$row->mobile}}</td>
                    <td>{{$row->address}}</td>
					<td>{{$row->address2}}</td>
                    <td>{{$row->city}}</td>
                    <td>{{$row->contact_person}}</td>
                    <td>{{$row->remarks}}</td>
                    <td>
                        <button type="button" class="btn btn-primary">View</button>
                        <button type="button" class="btn btn-success" value=""><a href="home?{{ $row->mobile }}">Edit</a></button>
                        <button type="button" class="btn btn-danger">Delete</button>
                    </td>
                </tr>
			
            @endforeach
                    	</table>    
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
